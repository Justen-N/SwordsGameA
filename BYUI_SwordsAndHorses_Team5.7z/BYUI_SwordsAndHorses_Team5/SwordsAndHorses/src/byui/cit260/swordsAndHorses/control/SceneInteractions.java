/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package byui.cit260.swords.control;

import java.util.Random;

/**
 *
 * @author Justen
 */
public class SceneInteractions {
    Random attackRoll= new Random();
    
    int n=attackRoll.nextInt(20)+1;
   
    
    
    
}
